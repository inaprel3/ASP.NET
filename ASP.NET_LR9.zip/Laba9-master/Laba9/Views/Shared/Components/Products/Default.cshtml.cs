using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba9.Views.Shared.Components.Products
{
    public class DefaultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
