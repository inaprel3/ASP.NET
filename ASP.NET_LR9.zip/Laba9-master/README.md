Результат:
![Результат](https://github.com/inaprel3/Laba9/blob/master/prodweath.png)
