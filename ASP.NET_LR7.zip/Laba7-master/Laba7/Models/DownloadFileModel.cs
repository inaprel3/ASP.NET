﻿namespace Laba7.Models
{
    public class DownloadFileModel
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? FileName { get; set; }
    }
}