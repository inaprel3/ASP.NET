using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba7.Views.File
{
    public class DownloadFileModel : PageModel
    {
        public void OnGet()
        { }
    }
}
