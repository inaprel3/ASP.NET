Вводимо дані:
![Дані](https://github.com/inaprel3/Laba7/blob/master/Data.png)
Файл зберігається:
![Збереження](https://github.com/inaprel3/Laba7/blob/master/Download.png)
Відкриваємо файл:
![Файл:](https://github.com/inaprel3/Laba7/blob/master/File.png)
