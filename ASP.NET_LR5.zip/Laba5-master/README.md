![Результат Library/Books:](https://github.com/inaprel3/Laba5/blob/master/homepage.png)
![Результат Library/Profile:](https://github.com/inaprel3/Laba5/blob/master/nodata.png)
![Результат Library:](https://github.com/inaprel3/Laba5/blob/master/data.png)
