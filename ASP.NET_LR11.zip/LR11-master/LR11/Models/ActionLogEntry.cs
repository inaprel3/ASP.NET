﻿namespace LR11.Models
{
    public class ActionLogEntry
    {
        public DateTime Time { get; set; }
        public string? MethodName { get; set; }
    }
}