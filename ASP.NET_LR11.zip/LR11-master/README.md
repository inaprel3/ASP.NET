Результат:
![Результат](https://github.com/inaprel3/LR11/blob/master/11.png)
