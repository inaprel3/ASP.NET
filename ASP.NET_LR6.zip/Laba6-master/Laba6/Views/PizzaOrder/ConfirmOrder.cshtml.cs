using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba6.Views.PizzaOrder
{
    public class ConfirmOrderModel : PageModel
    {
        public void OnGet() { }
    }
}