using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba6.Views.PizzaOrder
{
    public class ProcessOrderModel : PageModel
    {
        public void OnGet() { }
    }
}
