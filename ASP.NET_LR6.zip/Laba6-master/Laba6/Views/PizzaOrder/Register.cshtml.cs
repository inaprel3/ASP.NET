using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba6.Views.PizzaOrder
{
    public class RegisterModel : PageModel
    {
        public void OnGet() { }
    }
}
