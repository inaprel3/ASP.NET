namespace Laba6.Models
{
    public class User
    {
        public string? Name { get; set; }
        public int Age { get; set; }
    }
}
