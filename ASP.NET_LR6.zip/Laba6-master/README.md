Головна сторінка:
![Головна сторінка:](https://github.com/inaprel3/Laba6/blob/master/mainpage.png)
Сторінка регістрації клієнта:
![Сторінка регістрації клієнта:](https://github.com/inaprel3/Laba6/blob/master/registerpage.png)
Сторінка з введенням даних страви:
![Сторінка з введенням даних страви:](https://github.com/inaprel3/Laba6/blob/master/confirmorderpage.png)
Результат з виведенням інформації замовлення:
![Результат з виведенням інформації замовлення:](https://github.com/inaprel3/Laba6/blob/master/processesorderpage.png)
