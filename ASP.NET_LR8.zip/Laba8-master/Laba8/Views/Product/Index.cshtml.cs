using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba8.Views.Product
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
