Результат:
![Результат](https://github.com/inaprel3/Laba8/blob/master/lr8.png)
