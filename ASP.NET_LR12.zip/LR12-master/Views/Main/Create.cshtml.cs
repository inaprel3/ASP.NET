using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NET.Views.Main
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
