Результат:
![Результат](https://github.com/inaprel3/LR12/blob/master/12_1.png)
![Результат](https://github.com/inaprel3/LR12/blob/master/12_2.png)
![Результат](https://github.com/inaprel3/LR12/blob/master/12_3.png)
![Результат](https://github.com/inaprel3/LR12/blob/master/12_4.png)
