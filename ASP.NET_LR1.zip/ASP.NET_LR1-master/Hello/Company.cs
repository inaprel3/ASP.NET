public class Company
{
    public int CompanyId { get; set; } = 0; 
    public string Name { get; set; } = "";
    public string Location { get; set; } = "";
    public int YearFounded { get; set; } = 0; 
}
