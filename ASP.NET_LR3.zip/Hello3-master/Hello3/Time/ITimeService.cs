﻿namespace Hello3.Time {
    public interface ITimeService {
        public string GetTimeDay(DateTime dateTime);
    }
}