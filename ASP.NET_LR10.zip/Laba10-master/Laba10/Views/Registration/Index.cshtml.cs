using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Laba10.Views.Registration
{
    public class IndexModel : PageModel
    {
        public void OnGet() { }
    }
}
