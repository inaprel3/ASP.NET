Результат:
![Результат](https://github.com/inaprel3/Laba10/blob/master/10.1.png)
![Результат](https://github.com/inaprel3/Laba10/blob/master/10.2.png)
![Результат](https://github.com/inaprel3/Laba10/blob/master/10.3.png)
