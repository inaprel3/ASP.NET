![Результат Library:](https://github.com/inaprel3/Laba4/blob/master/LibraryPhoto.png)
![Результат Library/Books:](https://github.com/inaprel3/Laba4/blob/master/LibraryBooksPhoto.png)
![Результат Library/Profile:](https://github.com/inaprel3/Laba4/blob/master/LibraryProfilePhoto.png)
