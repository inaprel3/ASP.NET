﻿using System.Collections.Generic;
using Laba4;

namespace Laba4
{
    public class Books
    {
        public List<string> BookList { get; set; } = new List<string>();
    }
}